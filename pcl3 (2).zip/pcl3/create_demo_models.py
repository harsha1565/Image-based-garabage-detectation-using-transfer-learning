import tensorflow as tf
from tensorflow.keras.layers import Input, Flatten, Dense
from tensorflow.keras.models import Model
import numpy as np
import pickle

print("🔄 Creating demo models for instant testing...")

# Create dummy input
inp = Input(shape=(224, 224, 3))
x = Flatten()(inp)
x = Dense(128, activation='relu')(x)
out = Dense(5, activation='softmax')(x)

# Create simple model
resnet_demo = Model(inputs=inp, outputs=out)
vgg_demo = Model(inputs=inp, outputs=out)

# Compile
resnet_demo.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
vgg_demo.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Save models
print("💾 Saving demo ResNet50 model...")
resnet_demo.save("resnet_model.h5")
print("✓ resnet_model.h5 created")

print("💾 Saving demo VGG16 model...")
vgg_demo.save("vgg_model.h5")
print("✓ vgg_model.h5 created")

print("\n✅ Demo models ready!")
print("Note: These are lightweight demo models for testing the web app.")
print("For real training, run:")
print("  - python resnet_model.py")
print("  - python vgg_model.py")
