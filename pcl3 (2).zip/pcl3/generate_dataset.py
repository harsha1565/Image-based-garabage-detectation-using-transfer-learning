import os
import random
import numpy as np
from PIL import Image, ImageDraw

IMG_SIZE = 224
CLASSES = ['plastic', 'paper', 'metal', 'glass', 'organic']
TRAIN_IMAGES_PER_CLASS = 500
TEST_IMAGES_PER_CLASS = 100
BASE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dataset')


def ensure_directories():
    for subset in ['train', 'test']:
        for label in CLASSES:
            os.makedirs(os.path.join(BASE_PATH, subset, label), exist_ok=True)


def random_background(class_name=None):
    """Generate random background with natural variations suitable for each class"""
    if class_name == 'plastic':
        bg_colors = [
            [230, 240, 250],  # pale blue
            [235, 245, 255],  # off-white cool
            [240, 240, 245],  # soft gray-blue
        ]
    elif class_name == 'paper':
        bg_colors = [
            [245, 240, 225],  # cream
            [250, 245, 235],  # light parchment
            [235, 230, 215],  # soft beige
        ]
    elif class_name == 'metal':
        bg_colors = [
            [210, 210, 210],  # silver-gray
            [220, 220, 220],  # light steel
            [200, 200, 205],  # cool gray
        ]
    elif class_name == 'glass':
        bg_colors = [
            [220, 235, 245],  # light glass-blue
            [230, 240, 250],  # pale cyan
            [225, 235, 240],  # faint aqua
        ]
    elif class_name == 'organic':
        bg_colors = [
            [225, 235, 215],  # muted green
            [235, 240, 220],  # light moss
            [240, 245, 230],  # pale leaf
        ]
    else:
        bg_colors = [
            [200, 200, 200],
            [220, 220, 220],
            [180, 180, 180],
            [210, 210, 210],
        ]

    base_color = random.choice(bg_colors)
    background = Image.new('RGB', (IMG_SIZE, IMG_SIZE), tuple(base_color))
    arr = np.array(background).astype(np.float32)
    noise = np.random.normal(0, 6, arr.shape)
    arr = np.clip(arr + noise, 0, 255).astype(np.uint8)
    return Image.fromarray(arr)


def blend_color(color1, color2, weight):
    """Blend two colors"""
    return tuple(int(color1[i] * (1 - weight) + color2[i] * weight) for i in range(3))


def add_texture(image, texture_type, intensity=3):
    """Add texture to an image using PIL"""
    draw = ImageDraw.Draw(image)
    if texture_type == 'plastic_ridges':
        for y in range(10, IMG_SIZE - 10, 8):
            draw.line([(10, y), (IMG_SIZE - 10, y)], fill=(200, 200, 200), width=1)
    elif texture_type == 'metal_scratches':
        for _ in range(6):
            x1 = random.randint(20, IMG_SIZE - 40)
            y1 = random.randint(20, IMG_SIZE - 40)
            x2 = x1 + random.randint(15, 30)
            y2 = y1 + random.randint(-2, 2)
            draw.line([(x1, y1), (x2, y2)], fill=(220, 220, 220), width=1)
    return image


def draw_plastic(image):
    """Draw plastic bottle with CLEAR BLUE/COLORFUL appearance"""
    draw = ImageDraw.Draw(image)
    
    # Bottle position and size
    cx = random.randint(80, 140)
    cy = random.randint(50, 100)
    width = random.randint(40, 60)
    height = random.randint(100, 140)
    
    # BRIGHT, saturated colors for plastic (NOT metallic)
    plastic_colors = [
        (30, 150, 220),    # bright blue
        (50, 180, 255),    # bright cyan-blue
        (20, 140, 200),    # dark blue
        (200, 50, 150),    # magenta/pink
        (100, 220, 50),    # bright green
        (255, 150, 50),    # orange
    ]
    color = random.choice(plastic_colors)
    
    # Draw main bottle body
    x1 = cx - width//2
    y1 = cy
    x2 = cx + width//2
    y2 = cy + height
    
    # Draw bottle with gradient-like effect using multiple rectangles
    for layer in range(6):
        alpha_color = tuple(min(255, c + layer * 10) for c in color)
        draw.rectangle([x1 + layer, y1 + layer, x2 - layer, y2 - layer], 
                      fill=alpha_color, outline=None)
    
    # Draw bottle cap
    draw.rectangle([x1 - 3, y1 - 8, x2 + 3, y1], fill=(50, 50, 50))
    
    # Add ridges for plastic look
    for i in range(4):
        y = y1 + 20 + i * 25
        if y < y2:
            draw.line([(x1 + 5, y), (x2 - 5, y)], fill=(255, 255, 255), width=1)
    
    return image


def draw_paper(image):
    """Draw paper with TAN/BEIGE appearance and TEXT"""
    draw = ImageDraw.Draw(image)
    
    # LIGHT, cream-colored paper (NOT blue or bright colors)
    paper_colors = [
        (245, 240, 225),  # light cream
        (235, 230, 210),  # darker cream
        (250, 245, 235),  # lighter cream
        (240, 235, 220),  # medium cream
    ]
    base_color = random.choice(paper_colors)
    
    margin = random.randint(15, 25)
    paper_box = [margin, margin, IMG_SIZE - margin, IMG_SIZE - margin]
    draw.rectangle(paper_box, fill=base_color, outline=(200, 180, 150), width=2)
    
    # Draw text lines on paper
    lines = random.randint(8, 12)
    for i in range(lines):
        y = paper_box[1] + 20 + i * 16 + random.randint(-2, 2)
        draw.line([paper_box[0] + 14, y, paper_box[2] - 14, y], fill=(120, 110, 100), width=1)
    
    # Write random text-like marks
    for _ in range(15):
        x1 = random.randint(paper_box[0] + 18, paper_box[2] - 50)
        y1 = random.randint(paper_box[1] + 22, paper_box[3] - 22)
        x2 = x1 + random.randint(20, 50)
        y2 = y1 + random.randint(1, 3)
        draw.line([x1, y1, x2, y2], fill=(100, 90, 80), width=1)
    
    # Add fold/wrinkle lines
    if random.random() > 0.5:
        fold_x = random.randint(paper_box[0] + 30, paper_box[2] - 30)
        draw.line([fold_x, paper_box[1] + 10, fold_x, paper_box[3] - 10], fill=(220, 210, 195), width=2)
    
    # Add stains/marks
    for _ in range(random.randint(1, 3)):
        x = random.randint(paper_box[0] + 20, paper_box[2] - 20)
        y = random.randint(paper_box[1] + 20, paper_box[3] - 20)
        draw.ellipse([x-3, y-3, x+3, y+3], fill=(200, 185, 160))
    
    return image


def draw_metal(image):
    """Draw SILVER/GRAY metal can with REFLECTIONS and SCRATCHES"""
    draw = ImageDraw.Draw(image)
    
    # Metal can position
    cx = random.randint(80, 140)
    cy = random.randint(50, 90)
    width = random.randint(35, 55)
    height = random.randint(110, 140)
    
    x1 = cx - width//2
    y1 = cy
    x2 = cx + width//2
    y2 = cy + height
    
    # SILVERY METALLIC COLOR (NOT colorful like plastic)
    # Draw main can body with layered effect
    for layer in range(8):
        gray_val = 160 + layer * 8
        draw.rectangle([x1 + layer, y1 + layer, x2 - layer, y2 - layer], 
                      fill=(gray_val, gray_val, gray_val + 5), outline=None)
    
    # Draw can rims
    draw.rectangle([x1 - 2, y1 - 4, x2 + 2, y1], fill=(140, 140, 150))
    draw.rectangle([x1 - 2, y2, x2 + 2, y2 + 4], fill=(140, 140, 150))
    
    # Draw white reflective highlights (characteristic of metal)
    for offset in [10, 25, 40]:
        if y1 + offset < y2:
            draw.line([(x1 + 5, y1 + offset), (x2 - 5, y1 + offset)], fill=(240, 240, 245), width=2)
    
    # Add scratches
    for _ in range(4):
        x = random.randint(x1 + 5, x2 - 5)
        y = random.randint(y1 + 10, y2 - 10)
        draw.line([(x, y), (x + 15, y + 2)], fill=(200, 200, 210), width=1)
    
    return image


def draw_glass(image):
    """Draw TRANSPARENT glass bottle with BLUE TINT"""
    draw = ImageDraw.Draw(image)
    
    cx = random.randint(80, 140)
    cy = random.randint(50, 100)
    width = random.randint(38, 58)
    height = random.randint(115, 145)
    
    x1 = cx - width//2
    y1 = cy
    x2 = cx + width//2
    y2 = cy + height
    
    # TRANSPARENT BLUE-TINTED GLASS (darker than plastic)
    glass_colors = [
        (80, 140, 180),   # blue-tinted glass
        (100, 160, 200),  # lighter blue glass
        (70, 130, 170),   # darker blue glass
    ]
    glass_color = random.choice(glass_colors)
    
    # Draw glass body with layered effect
    for layer in range(5):
        shade = tuple(max(0, c - layer * 5) for c in glass_color)
        draw.rectangle([x1 + layer, y1 + layer, x2 - layer, y2 - layer], 
                      fill=shade, outline=None)
    
    # Draw bottle neck
    neck_x1 = cx - width//5
    neck_x2 = cx + width//5
    draw.rectangle([neck_x1, y1 - 12, neck_x2, y1+3], fill=glass_color)
    
    # Add glass highlights (refraction)
    draw.line([(x1 + 6, y1 + 15), (x1 + 6, y2 - 15)], fill=(200, 220, 240), width=2)
    draw.line([(x2 - 6, y1 + 30), (x2 - 6, y2 - 30)], fill=(200, 220, 240), width=1)
    
    return image


def draw_organic(image):
    """Draw COLORFUL organic waste with FRUITS and LEAVES"""
    draw = ImageDraw.Draw(image)
    
    # Organic items with bright, natural colors (distinct from plastic/metal)
    items = [
        (220, 60, 50),      # red apple
        (255, 140, 30),     # orange
        (180, 150, 50),     # yellow banana
        (100, 180, 60),     # green lime
    ]
    
    num_items = random.randint(2, 4)
    
    for _ in range(num_items):
        color = random.choice(items)
        radius = random.randint(18, 28)
        
        center_x = random.randint(55, IMG_SIZE - 55)
        center_y = random.randint(70, IMG_SIZE - 55)
        
        # Draw fruit
        draw.ellipse([center_x - radius, center_y - radius, 
                     center_x + radius, center_y + radius], fill=color)
        
        # Add highlight
        highlight = tuple(min(255, c + 40) for c in color)
        draw.ellipse([center_x - radius + 4, center_y - radius + 4,
                     center_x + radius - 12, center_y - radius + 16], 
                    outline=highlight, width=1)
        
        # Add leaf
        leaf_x = center_x + radius - 2
        leaf_y = center_y - radius - 5
        leaf_color = (80, 140, 60)
        draw.ellipse([leaf_x, leaf_y, leaf_x + 12, leaf_y + 16], fill=leaf_color)
        draw.line([leaf_x + 6, leaf_y + 2, leaf_x + 6, leaf_y + 14], 
                 fill=(50, 100, 30), width=1)
    
    # Add compost/soil texture at bottom
    compost_y = random.randint(160, 180)
    draw.rectangle([20, compost_y, IMG_SIZE - 20, IMG_SIZE - 10], fill=(120, 90, 50))
    
    # Add texture to compost
    for _ in range(3):
        x = random.randint(30, IMG_SIZE - 30)
        y = random.randint(compost_y + 5, IMG_SIZE - 15)
        draw.ellipse([x - 2, y - 2, x + 2, y + 2], fill=(100, 70, 35))
    
    return image


def add_noise(image):
    """Add slight noise to image"""
    arr = np.array(image).astype(np.int16)
    noise = np.random.normal(0, 4, arr.shape).astype(np.int16)
    arr = np.clip(arr + noise, 0, 255).astype(np.uint8)
    return Image.fromarray(arr)


def create_image_for_class(class_name):
    """Create a synthetic image for a garbage class"""
    image = random_background(class_name)
    if class_name == 'plastic':
        image = draw_plastic(image)
    elif class_name == 'paper':
        image = draw_paper(image)
    elif class_name == 'metal':
        image = draw_metal(image)
    elif class_name == 'glass':
        image = draw_glass(image)
    elif class_name == 'organic':
        image = draw_organic(image)
    return add_noise(image)


def create_synthetic_dataset():
    """Generate complete synthetic dataset"""
    ensure_directories()
    print('📊 Starting synthetic dataset generation...')
    print(f'Creating {TRAIN_IMAGES_PER_CLASS} training images per class')
    print(f'Creating {TEST_IMAGES_PER_CLASS} test images per class\n')

    for subset, count in [('train', TRAIN_IMAGES_PER_CLASS), ('test', TEST_IMAGES_PER_CLASS)]:
        print(f'🎨 Generating {subset.upper()} images...')
        for class_name in CLASSES:
            for i in range(count):
                img = create_image_for_class(class_name)
                save_path = os.path.join(BASE_PATH, subset, class_name, f'{class_name}_{i:04d}.jpg')
                img.save(save_path, quality=90)
            print(f'  ✓ {class_name}: {count}/{count} {subset} images')
        print('')

    total_train = TRAIN_IMAGES_PER_CLASS * len(CLASSES)
    total_test = TEST_IMAGES_PER_CLASS * len(CLASSES)
    print('✅ Dataset generation completed!')
    print(f'Total training images: {total_train}')
    print(f'Total test images: {total_test}')


if __name__ == '__main__':
    create_synthetic_dataset()
