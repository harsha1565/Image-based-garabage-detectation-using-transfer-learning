# 🚀 HOW TO RUN THE PROJECT - COMPLETE GUIDE

## ✅ Current Status

**The project is READY TO RUN!** 

- ✓ All files created
- ✓ All dependencies installed
- ✓ Dataset generated
- ✓ Demo models created
- ✓ Flask app running on `http://127.0.0.1:5000/`

---

## 📋 PROJECT SUMMARY

This is a **Garbage Classification** project using Deep Learning with:
- **ResNet50** & **VGG16** models
- **Transfer Learning** from ImageNet
- **Synthetic dataset** with 5 garbage classes (Plastic, Paper, Metal, Glass, Organic)
- **Flask web app** with beautiful UI
- **Real-time predictions** comparing both models

---

## 🎯 STEP-BY-STEP EXECUTION

### **Step 1: Open Project in VS Code**

```bash
# Navigate to the project folder
File → Open Folder → C:\Users\Dharnish\Documents\PCL\Waste-or-Garbage-Classification-Using-Deep-Learning
```

### **Step 2: Open Terminal**

```bash
# Click Terminal → New Terminal (or press Ctrl+`)
```

### **Step 3: Create Virtual Environment**

```bash
python -m venv venv
```

### **Step 4: Activate Virtual Environment**

```bash
# Windows PowerShell
venv\Scripts\Activate.ps1

# Or Windows Command Prompt
venv\Scripts\activate
```

**You should see: `(venv)` at the start of terminal line**

### **Step 5: Install All Requirements**

```bash
pip install -r requirements.txt
```

This installs:
- TensorFlow & Keras
- NumPy, Matplotlib
- Flask, Werkzeug
- Pillow, OpenCV
- Scikit-learn

⏱️ **Takes 3-5 minutes** on first install

### **Step 6: Generate Synthetic Dataset**

```bash
python generate_dataset.py
```

**Output:**
- Creates 500 training images (100 per class × 5 classes)
- Creates 100 test images (20 per class × 5 classes)
- Stored in `dataset/train/` and `dataset/test/`
- ⏱️ Takes ~1-2 minutes

### **Step 7A: Train Real Models (Optional - Takes 30+ minutes)**

If you want to train actual models on real data:

```bash
# Train ResNet50
python resnet_model.py

# Then train VGG16
python vgg_model.py
```

**What happens:**
- Downloads pre-trained models from ImageNet
- Trains on your dataset
- Generates accuracy & loss graphs
- Saves trained models as `.h5` files

⏱️ **ResNet50:** 10-15 min | **VGG16:** 15-20 min (on CPU)

### **Step 7B: Use Demo Models (Ready Now)**

The project comes with lightweight demo models:

```bash
python create_demo_models.py
```

**Result:** Instant models ready for testing the web app!

### **Step 8: Start Flask Web Application**

```bash
python app.py
```

**Output:**
```
============================================================
🌐 Starting Garbage Classification Web App
============================================================
📍 Open browser: http://127.0.0.1:5000/
============================================================

 * Running on http://127.0.0.1:5000
```

### **Step 9: Open Web App in Browser**

Click the link or manually visit:

```
http://127.0.0.1:5000/
```

### **Step 10: Test the Application**

1. Click the upload box or drag an image
2. Click "🚀 Predict Class" button
3. View predictions from both models
4. Check consensus indicator
5. Read garbage class information

---

## 📁 PROJECT FOLDER STRUCTURE

```
Waste-or-Garbage-Classification-Using-Deep-Learning/
│
├── 📄 app.py                          # Flask web application
├── 📄 generate_dataset.py             # Create synthetic images
├── 📄 resnet_model.py                 # Train ResNet50 model
├── 📄 vgg_model.py                    # Train VGG16 model
├── 📄 create_demo_models.py           # Create demo models
├── 📄 compare.py                      # Model comparison script
│
├── 📁 dataset/
│   ├── train/                         # Training images
│   │   ├── plastic/
│   │   ├── paper/
│   │   ├── metal/
│   │   ├── glass/
│   │   └── organic/
│   └── test/                          # Test images
│       ├── plastic/
│       ├── paper/
│       ├── metal/
│       ├── glass/
│       └── organic/
│
├── 📁 templates/
│   └── index.html                     # Web interface
│
├── 📁 static/
│   ├── style.css                      # Styling
│   └── uploads/                       # Uploaded images
│
├── 📄 requirements.txt                # Python dependencies
├── 📄 resnet_model.h5                 # Trained/Demo ResNet50
├── 📄 vgg_model.h5                    # Trained/Demo VGG16
├── 📄 README.md                       # Full documentation
└── 📄 QUICKSTART.md                   # Quick reference

```

---

## 📊 EXECUTION TIMELINE

### **Quick Demo (5-10 minutes)**

```
1. Generate Dataset ─────────────────── 1-2 min
2. Create Demo Models ───────────────── 1 min
3. Start Flask App ──────────────────── 0.5 min
4. Test in Browser ──────────────────── 1-5 min
Total: ~5-10 minutes ✓
```

### **Full Training (45-60 minutes)**

```
1. Generate Dataset ─────────────────── 1-2 min
2. Train ResNet50 ───────────────────── 10-15 min
3. Train VGG16 ──────────────────────── 15-20 min
4. View Graphs ──────────────────────── 1 min
5. Start Flask App ──────────────────── 0.5 min
6. Test in Browser ──────────────────── 2-5 min
Total: ~45-60 minutes ✓
```

---

## ⚙️ COMMAND REFERENCE

### **One-Time Setup**

```bash
# Create environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### **Running the Project**

```bash
# Generate dataset
python generate_dataset.py

# Create demo models (use demo)
python create_demo_models.py

# OR train real models (takes 30+ min)
python resnet_model.py
python vgg_model.py

# Start web app
python app.py

# Open http://127.0.0.1:5000/
```

### **Stopping the App**

```bash
# In terminal: Press Ctrl+C
```

---

## 🎮 WEB APP FEATURES

### **Upload Image**
- Drag & drop support
- Click to browse files
- Supports: JPG, PNG, GIF, BMP
- Max 16MB file size

### **Get Predictions**
- Automatic preprocessing
- ResNet50 prediction with confidence
- VGG16 prediction with confidence
- Consensus indicator

### **View Results**
- Uploaded image display
- Model predictions side-by-side
- Confidence percentages
- Garbage class information
- Environmental facts

### **Class Information**
- Description of each class
- Recyclability status
- Decomposition time
- Emoji icons for quick recognition

---

## 🔧 TROUBLESHOOTING

### **Issue: "Module not found" error**

**Solution:** Install dependencies again
```bash
pip install -r requirements.txt
```

### **Issue: "resnet_model.h5 not found" when running Flask app**

**Solution:** Create demo models
```bash
python create_demo_models.py
```

### **Issue: Port 5000 already in use**

**Solution:** Edit `app.py`, change the port number:
```python
# Change this line near the end:
app.run(debug=True, host='127.0.0.1', port=5001)  # Changed to 5001
```

Then access: `http://127.0.0.1:5001/`

### **Issue: Out of memory error during training**

**Solution:** Reduce batch size in training scripts
```python
# In resnet_model.py or vgg_model.py, change:
BATCH_SIZE = 8  # Reduced from 16
```

### **Issue: Very slow training**

**Reason:** Training on CPU is slow (normal)

**Solutions:**
- Be patient (let it run overnight)
- Use GPU (if available)
- Reduce epochs: `EPOCHS = 1`
- Reduce dataset size

### **Issue: Browser can't access localhost:5000**

**Solution:** Make sure terminal shows the Flask app is running:
```
* Running on http://127.0.0.1:5000
```

If not running, execute:
```bash
python app.py
```

---

## 📚 LEARNING OUTCOMES

After completing this project, you'll understand:

✅ **Transfer Learning** - Using pre-trained models  
✅ **ResNet50** - Skip connections, residual blocks  
✅ **VGG16** - Simple sequential architecture  
✅ **Image Classification** - Preprocessing, augmentation  
✅ **Model Training** - Epochs, batches, accuracy curves  
✅ **Flask Web Apps** - Routes, templates, static files  
✅ **HTML/CSS** - Modern responsive design  
✅ **API Integration** - Frontend to backend communication  

---

## 🎓 VIVA QUESTIONS QUICK ANSWERS

**Q: What is Transfer Learning?**
A: Using pre-trained models from large datasets (ImageNet) instead of training from scratch. Saves time and improves accuracy.

**Q: Why ResNet50 over VGG16?**
A: ResNet50 has skip connections preventing vanishing gradients, making it faster and more accurate than plain VGG16.

**Q: What image size is used?**
A: 224×224 pixels (standard for ImageNet pre-trained models)

**Q: How many training images?**
A: 500 total (100 per class × 5 classes) + 100 test images

**Q: What are the 5 garbage classes?**
A: Plastic, Paper, Metal, Glass, Organic

**Q: What data augmentation is used?**
A: Rotation, zoom, width/height shift, horizontal flip

**Q: What's the difference between train and test data?**
A: Train data (80%) trains the model, test data (20%) evaluates its performance on unseen data

**Q: How long does training take?**
A: ~10-15 min (ResNet50) + ~15-20 min (VGG16) on CPU

---

## 💾 MODEL DETAILS

### **ResNet50**
- Depth: 50 layers
- Architecture: Skip connections (advanced)
- Parameters: ~25 million
- Typical accuracy: 85-95%
- Training time (CPU): 10-15 min
- Pros: Better accuracy, faster
- Best for: General use cases

### **VGG16**
- Depth: 16 layers  
- Architecture: Sequential stacking (simple)
- Parameters: ~138 million
- Typical accuracy: 80-90%
- Training time (CPU): 15-20 min
- Pros: More interpretable
- Best for: Educational purposes

---

## 🌐 WEB APP ARCHITECTURE

```
┌─────────────────┐
│   Browser       │
│  (HTML/CSS/JS)  │
└────────┬────────┘
         │ HTTP Request
         ↓
┌─────────────────┐
│  Flask Server   │
│   (Python)      │
└────────┬────────┘
         │
    ┌────┴────┐
    ↓         ↓
┌────────┐ ┌────────┐
│ResNet50│ │VGG16   │
│ Model  │ │ Model  │
└────────┘ └────────┘
```

---

## ✨ NEXT STEPS (After You Master This)

1. **Use Real Dataset**
   - Download from Google Open Images
   - Train with more epochs
   - Achieve higher accuracy

2. **Fine-tuning**
   - Unfreeze some layers
   - Lower learning rate
   - Get better results

3. **Deploy Online**
   - Use Heroku, AWS, or Google Cloud
   - Share link with others
   - Make it publicly accessible

4. **Add More Models**
   - Try MobileNet (faster)
   - Try EfficientNet (better)
   - Compare more architectures

5. **Advanced Features**
   - Batch predictions
   - Confidence threshold
   - Export predictions to CSV
   - Real-time demo video

---

## 📞 QUICK HELP

**Can't find something?** Check these files:
- `README.md` - Full documentation
- `QUICKSTART.md` - Quick start guide
- Code comments in each `.py` file

**Need to change something?**
- Edit `app.py` for Flask app logic
- Edit `templates/index.html` for web interface
- Edit `static/style.css` for styling
- Edit `resnet_model.py` or `vgg_model.py` for training

---

## ✅ SUCCESS CHECKLIST

Before submitting your project, ensure:

- [ ] Virtual environment is working
- [ ] All dependencies installed
- [ ] Dataset generated successfully
- [ ] Models trained OR demo models created
- [ ] Flask app running without errors
- [ ] Web interface loads at http://127.0.0.1:5000/
- [ ] Can upload image and get predictions
- [ ] Both models show predictions
- [ ] Accuracy graphs are generated
- [ ] README.md is complete

---

**🎉 YOU'RE ALL SET!**

Run this in order:
```bash
# 1. Setup
venv\Scripts\activate
pip install -r requirements.txt

# 2. Prepare
python generate_dataset.py
python create_demo_models.py

# 3. Run
python app.py

# 4. Visit http://127.0.0.1:5000/
```

**Happy Garbage Classification! ♻️🤖**

---

*Last Updated: April 7, 2026*
