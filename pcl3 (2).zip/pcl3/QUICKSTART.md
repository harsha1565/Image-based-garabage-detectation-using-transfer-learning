# 🚀 QUICK START GUIDE

## 5-Minute Setup Instructions

### 1. Open Terminal in VS Code

Click on Terminal → New Terminal (or Ctrl+`)

### 2. Create Virtual Environment

```bash
python -m venv venv
```

### 3. Activate Virtual Environment (Windows)

```bash
venv\Scripts\activate
```

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

⏸️ Wait for installation to complete (usually 2-3 minutes)

### 5. Generate Dataset

```bash
python generate_dataset.py
```

✓ Creates 700 training + test images (automatic)

### 6. Train ResNet50 Model (Option A)

```bash
python resnet_model.py
```

⏸️ Training takes 2-5 minutes depending on your CPU
✓ Creates: resnet_model.h5 + resnet_graphs.png

### 7. Train VGG16 Model (Option B)

```bash
python vgg_model.py
```

⏸️ Training takes 2-5 minutes
✓ Creates: vgg_model.h5 + vgg_graphs.png

### 8. Start Web App

```bash
python app.py
```

✓ Output will show:
```
========================================
🌐 Starting Garbage Classification Web App
========================================
📍 Open browser: http://127.0.0.1:5000/
========================================
```

### 9. Open in Browser

Click on the link or paste: **http://127.0.0.1:5000/**

### 10. Test the App

1. Click "Upload Image" or drag an image
2. Click "🚀 Predict Class"
3. View predictions from both models
4. Check consensus and class info

---

## 📁 What Each File Does

| File | Purpose |
|------|---------|
| `generate_dataset.py` | Creates synthetic garbage images |
| `resnet_model.py` | Trains ResNet50 model |
| `vgg_model.py` | Trains VGG16 model |
| `app.py` | Flask web application |
| `templates/index.html` | Web interface |
| `static/style.css` | Styling |

---

## ✅ Success Checklist

- [ ] Virtual environment activated
- [ ] All dependencies installed
- [ ] Dataset generated (700+ images)
- [ ] ResNet50 trained (resnet_model.h5 created)
- [ ] VGG16 trained (vgg_model.h5 created)
- [ ] Flask app running on port 5000
- [ ] Web interface loads at 127.0.0.1:5000

---

## 🎯 Project Workflow

```
START
  ↓
[1] Generate Dataset (2-3 min)
  ↓
[2] Train ResNet50 (2-5 min)
  ↓
[3] Train VGG16 (2-5 min)
  ↓
[4] Start Flask App
  ↓
[5] Upload Image & Get Predictions
  ↓
DONE ✓
```

---

## 💡 Tips

- **GPU Training**: If you have NVIDIA GPU, training is 5-10x faster
- **Stop Training**: Press Ctrl+C to stop training scripts
- **Stop Flask App**: Press Ctrl+C in terminal
- **Port Error**: If 5000 is used, edit app.py and change port

---

## 🎮 How to Use the Web App

1. **Upload Image**
   - Click the upload box
   - Select an image (JPG, PNG, etc.)
   - Or drag & drop

2. **Get Predictions**
   - Click "🚀 Predict Class" button
   - Wait for processing (~2-3 seconds)
   - View results

3. **Understand Results**
   - ResNet50 prediction with confidence
   - VGG16 prediction with confidence
   - Consensus indicator (agreement/disagreement)
   - Class information and facts

4. **Test Another Image**
   - Click "🔄 Classify Another Image"
   - Repeat process

---

## ⚠️ Common Issues & Fixes

### Issue: "Module not found"
**Fix:** Install dependencies again
```bash
pip install -r requirements.txt
```

### Issue: "Model not found" in Flask
**Fix:** Train both models first
```bash
python generate_dataset.py
python resnet_model.py
python vgg_model.py
```

### Issue: Port 5000 already in use
**Fix:** Edit app.py, last line:
```python
app.run(debug=True, host='127.0.0.1', port=5001)  # Changed to 5001
```

### Issue: Slow training
**Fix:** This is normal on CPU. Be patient or use GPU.

### Issue: Out of memory
**Fix:** In resnet_model.py and vgg_model.py, change:
```python
BATCH_SIZE = 16  # Reduced from 32
```

---

## 📊 What You'll See

### Training Output:
```
Epoch 1/5
100/100 ━━━━━━━━━━━━━━━━ 45s 450ms/step - loss: 1.5234 - accuracy: 0.5234
Epoch 2/5
100/100 ━━━━━━━━━━━━━━━━ 40s 400ms/step - loss: 0.8234 - accuracy: 0.7234
...
Final Training Accuracy: 0.8934 (89.34%)
Final Validation Accuracy: 0.8245 (82.45%)
```

### Web App Output:
- Uploaded image displayed
- ResNet50: PLASTIC (92.34% confidence)
- VGG16: PLASTIC (88.45% confidence)
- ✓ CONSENSUS - Both models agree!

---

## 🎓 Learning Outcomes

After completing this project, you'll understand:
- ✓ Transfer learning
- ✓ ResNet50 architecture
- ✓ VGG16 architecture
- ✓ Image classification
- ✓ Model comparison
- ✓ Web application creation
- ✓ Flask framework

---

## 🏁 Final Notes

- Total setup time: ~15-20 minutes (including training)
- First time will be slower as it downloads models
- Remember to activate virtual environment before running code
- Keep all files in the same directory structure

---

## ✨ You're All Set!

Run in this order:
1. `python generate_dataset.py`
2. `python resnet_model.py`
3. `python vgg_model.py`
4. `python app.py`

Then open **http://127.0.0.1:5000/** in your browser! 🎉

---

**Happy Learning! ♻️🤖**
