import os
import json
from app import app

if __name__ == '__main__':
    client = app.test_client()
    sample_image = os.path.join('dataset', 'test', 'plastic', 'plastic_0.jpg')
    if not os.path.exists(sample_image):
        raise FileNotFoundError(sample_image)

    with open(sample_image, 'rb') as f:
        data = {'file': (f, 'plastic_0.jpg')}
        response = client.post('/predict', data=data, content_type='multipart/form-data')
        print('status_code:', response.status_code)
        print('json:', json.dumps(response.get_json(), indent=2))
