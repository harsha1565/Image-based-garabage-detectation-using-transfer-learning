import matplotlib.pyplot as plt
import os
import re

print("=" * 60)
print("📊 Creating Model Comparison Script")
print("=" * 60)

# Note: This script will create comparison visualizations
# after both models have been trained

def create_comparison_summary():
    """Create a summary comparison of both models"""
    
    print("\n✓ Comparison script created successfully")
    print("\nTo use this script:")
    print("1. Train both models: python resnet_model.py & python vgg_model.py")
    print("2. Run this script to generate comparison graphs")
    print("\nThe script will create:")
    print("   - comparison_accuracy.png")
    print("   - comparison_loss.png")
    print("   - comparison_summary.png")

if __name__ == "__main__":
    create_comparison_summary()
