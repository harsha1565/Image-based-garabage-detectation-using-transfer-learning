import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout, BatchNormalization
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
import matplotlib.pyplot as plt

print("=" * 60)
print("🚀 ResNet50 Model Training for Garbage Classification")
print("=" * 60)

# Configuration
IMG_SIZE = 224
BATCH_SIZE = 16
INITIAL_EPOCHS = 10
FINE_TUNE_EPOCHS = 8
EPOCHS = INITIAL_EPOCHS + FINE_TUNE_EPOCHS

# Check if GPU is available
print(f"\n🔧 GPU Available: {tf.config.list_physical_devices('GPU')}")

# Data Preparation
print("\n📁 Loading dataset...")
train_datagen = ImageDataGenerator(
    rescale=1.0 / 255.0,
    rotation_range=25,
    width_shift_range=0.15,
    height_shift_range=0.15,
    zoom_range=0.18,
    horizontal_flip=True,
    fill_mode='nearest'
)

test_datagen = ImageDataGenerator(rescale=1.0 / 255.0)

train_data = train_datagen.flow_from_directory(
    'dataset/train',
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode='categorical'
)

test_data = test_datagen.flow_from_directory(
    'dataset/test',
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode='categorical'
)

print(f"✓ Training samples: {train_data.samples}")
print(f"✓ Test samples: {test_data.samples}")
print(f"✓ Classes: {train_data.class_indices}")

# Build Model
print("\n🏗️  Building ResNet50 Model...")
base_model = ResNet50(
    weights='imagenet',
    include_top=False,
    input_shape=(IMG_SIZE, IMG_SIZE, 3)
)

# Freeze base model
for layer in base_model.layers:
    layer.trainable = False

print(f"✓ Base model layers frozen: {len(base_model.layers)}")

# Add custom classification layers
x = GlobalAveragePooling2D()(base_model.output)
x = Dense(256, activation='relu')(x)
x = BatchNormalization()(x)
x = Dropout(0.5)(x)
x = Dense(128, activation='relu')(x)
x = BatchNormalization()(x)
x = Dropout(0.3)(x)
output = Dense(train_data.num_classes, activation='softmax')(x)

model = Model(inputs=base_model.input, outputs=output)

# Compile
model.compile(
    optimizer=Adam(learning_rate=0.0005),
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

print("\n📊 Model Summary:")
model.summary()

# Callbacks
callbacks = [
    EarlyStopping(monitor='val_accuracy', patience=3, restore_best_weights=True, verbose=1),
    ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=2, min_lr=1e-6, verbose=1)
]

# Train
print("\n🎓 Starting initial training...")
history = model.fit(
    train_data,
    validation_data=test_data,
    epochs=INITIAL_EPOCHS,
    callbacks=callbacks,
    verbose=1
)

# Fine-tune top ResNet layers
print("\n🔧 Fine-tuning top ResNet50 layers...")
for layer in base_model.layers[-20:]:
    layer.trainable = True

model.compile(
    optimizer=Adam(learning_rate=1e-5),
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

history_fine = model.fit(
    train_data,
    validation_data=test_data,
    epochs=EPOCHS,
    initial_epoch=INITIAL_EPOCHS,
    callbacks=callbacks,
    verbose=1
)

# Save model
print("\n💾 Saving model...")
model.save('resnet_model.h5')
print("✓ Model saved as resnet_model.h5")

# Merge history for plotting
train_acc = history.history['accuracy'] + history_fine.history['accuracy']
val_acc = history.history['val_accuracy'] + history_fine.history['val_accuracy']
train_loss = history.history['loss'] + history_fine.history['loss']
val_loss = history.history['val_loss'] + history_fine.history['val_loss']

# Generate graphs
print("\n📈 Generating graphs...")
plt.figure(figsize=(14, 6))

# Accuracy Graph
plt.subplot(1, 2, 1)
plt.plot(train_acc, label='Training Accuracy', linewidth=2)
plt.plot(val_acc, label='Validation Accuracy', linewidth=2)
plt.title('ResNet50 - Model Accuracy', fontsize=14)
plt.xlabel('Epoch', fontsize=12)
plt.ylabel('Accuracy', fontsize=12)
plt.legend(fontsize=10)
plt.grid(True, alpha=0.3)

# Loss Graph
plt.subplot(1, 2, 2)
plt.plot(train_loss, label='Training Loss', linewidth=2)
plt.plot(val_loss, label='Validation Loss', linewidth=2)
plt.title('ResNet50 - Model Loss', fontsize=14)
plt.xlabel('Epoch', fontsize=12)
plt.ylabel('Loss', fontsize=12)
plt.legend(fontsize=10)
plt.grid(True, alpha=3)

plt.tight_layout()
plt.savefig('resnet_graphs.png', dpi=300, bbox_inches='tight')
plt.close()
print('✓ Graph saved as resnet_graphs.png')

print("\n" + "=" * 60)
print("✅ ResNet50 Training Complete!")
print("=" * 60)
final_train_acc = history.history['accuracy'][-1]
final_val_acc = history.history['val_accuracy'][-1]
print(f"Final Training Accuracy: {final_train_acc:.4f} ({final_train_acc * 100:.2f}%)")
print(f"Final Validation Accuracy: {final_val_acc:.4f} ({final_val_acc * 100:.2f}%)")
print("=" * 60)
