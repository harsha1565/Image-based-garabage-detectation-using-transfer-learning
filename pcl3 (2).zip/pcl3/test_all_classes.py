import os
import json
from app import app

def test_class(class_name):
    client = app.test_client()
    sample_image = os.path.join('dataset', 'test', class_name, f'{class_name}_0.jpg')
    if not os.path.exists(sample_image):
        print(f'❌ Sample image for {class_name} not found: {sample_image}')
        return

    with open(sample_image, 'rb') as f:
        data = {'file': (f, f'{class_name}_0.jpg')}
        response = client.post('/predict', data=data, content_type='multipart/form-data')
        if response.status_code == 200:
            result = response.get_json()
            predicted = result['final_prediction']['class'].lower()
            confidence = result['final_prediction']['confidence']
            print(f'✅ {class_name.upper()} -> {predicted.upper()} ({confidence})')
            if predicted == class_name:
                print('   ✓ Correct classification')
            else:
                print('   ❌ Incorrect classification')
        else:
            print(f'❌ Error for {class_name}: {response.status_code}')

if __name__ == '__main__':
    classes = ['plastic', 'paper', 'glass', 'organic']
    print('Testing all classes with sample images:')
    for cls in classes:
        test_class(cls)
    print('\nTest complete.')