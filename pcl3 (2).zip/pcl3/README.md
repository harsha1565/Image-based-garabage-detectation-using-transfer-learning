# 🗑️ Garbage Classification Using Deep Learning
## Transfer Learning with ResNet50 & VGG16

A complete deep learning project for waste classification using Transfer Learning, comparing ResNet50 and VGG16 architectures with a beautiful Flask web application.

---

## 📋 Project Overview

This project demonstrates:
- **Transfer Learning**: Using pre-trained ResNet50 and VGG16 models from ImageNet
- **Data Classification**: Classifies garbage into 5 categories: Plastic, Paper, Metal, Glass, Organic
- **Model Comparison**: Side-by-side comparison of two state-of-the-art architectures
- **Web Interface**: Interactive Flask web app for real-time predictions
- **Synthetic Dataset**: Automatic dataset generation with 100 training + 20 test images per class

---

## 🎯 Garbage Classes

1. **Plastic** 🎁 - Bottles, bags, containers, wrappers
2. **Paper** 📄 - Newspapers, cardboard, magazines
3. **Metal** 🔩 - Cans, aluminum, wires
4. **Glass** 🍶 - Bottles, jars, windows
5. **Organic** 🍎 - Food waste, leaves, plants

---

## 📁 Project Structure

```
Waste-or-Garbage-Classification-Using-Deep-Learning/
│
├── generate_dataset.py          # Generate synthetic dataset
├── resnet_model.py              # ResNet50 training script
├── vgg_model.py                 # VGG16 training script
├── app.py                       # Flask web application
│
├── dataset/
│   ├── train/
│   │   ├── plastic/            # Training images for plastic
│   │   ├── paper/
│   │   ├── metal/
│   │   ├── glass/
│   │   └── organic/
│   │
│   └── test/
│       ├── plastic/            # Test images for plastic
│       ├── paper/
│       ├── metal/
│       ├── glass/
│       └── organic/
│
├── templates/
│   └── index.html              # Web interface
│
├── static/
│   ├── style.css               # Styling
│   └── uploads/                # Uploaded images
│
├── requirements.txt            # Python dependencies
├── resnet_model.h5            # Trained ResNet50 model
├── vgg_model.h5               # Trained VGG16 model
├── resnet_graphs.png          # ResNet50 training graphs
└── vgg_graphs.png             # VGG16 training graphs
```

---

## 🚀 Step-by-Step Installation & Execution

### Step 1️⃣: Open in VS Code

```bash
# Open the project folder
File → Open Folder → select Waste-or-Garbage-Classification-Using-Deep-Learning
```

### Step 2️⃣: Create Virtual Environment

Open terminal and run:

```bash
python -m venv venv
```

Activate it (Windows):
```bash
venv\Scripts\activate
```

### Step 3️⃣: Install Dependencies

```bash
pip install -r requirements.txt
```

This installs:
- TensorFlow & Keras
- NumPy, Matplotlib
- Flask
- Pillow, OpenCV
- Scikit-learn

### Step 4️⃣: Generate Synthetic Dataset

```bash
python generate_dataset.py
```

**Output:**
- 600 training images (100 per class × 5 classes)
- 100 test images (20 per class × 5 classes)
- Images stored in `dataset/train/` and `dataset/test/`

### Step 5️⃣: Train ResNet50 Model

```bash
python resnet_model.py
```

**Output:**
- `resnet_model.h5` - Trained model
- `resnet_graphs.png` - Accuracy & Loss graphs
- Final accuracy displayed in terminal

### Step 6️⃣: Train VGG16 Model

```bash
python vgg_model.py
```

**Output:**
- `vgg_model.h5` - Trained model
- `vgg_graphs.png` - Accuracy & Loss graphs
- Final accuracy displayed in terminal

### Step 7️⃣: Start Web Application

```bash
python app.py
```

**Output:**
```
========================================
🌐 Starting Garbage Classification Web App
========================================
📍 Open browser: http://127.0.0.1:5000/
========================================
```

### Step 8️⃣: Open in Browser

Navigate to: **http://127.0.0.1:5000/**

---

## 🎨 Web Application Features

### Upload Image
- Drag & drop or click to upload garbage image
- Supports: JPG, PNG, GIF, BMP (max 16MB)

### Real-Time Predictions
- Both models predict simultaneously
- Confidence scores displayed
- Consensus indicator shows agreement

### Model Comparison
- Side-by-side predictions
- Individual confidence levels
- Model architecture details

### Class Information
- Garbage classifications explained
- Recyclability status
- Decomposition times

---

## 📊 Model Comparison

| Feature | ResNet50 | VGG16 |
|---------|----------|-------|
| **Architecture** | Skip Connections | Sequential |
| **Depth** | 50 Layers | 16 Layers |
| **Speed** | ⚡ Faster | 🐌 Slower |
| **Accuracy** | ✓ Higher | ✓ Good |
| **Parameters** | ~25M | ~138M |
| **Best For** | General use | Interpretability |

---

## 🔑 Key Features

### ✅ Automatic Dataset Generation
Create synthetic garbage images without downloading datasets

### ✅ Transfer Learning
Pre-trained models from ImageNet for faster convergence

### ✅ Data Augmentation
Rotation, zoom, shift, flip for better generalization

### ✅ Dual Model Comparison
Compare accuracy and predictions side-by-side

### ✅ Beautiful UI
Modern, responsive web interface with drag-drop

### ✅ Real-Time Predictions
Instant predictions using trained models

---

## 📈 Training Graphs

### ResNet50
- Accuracy curves showing training vs validation
- Loss curves for both training and validation
- Convergence analysis

### VGG16
- Similar metrics for comparison
- Training progression visualization

---

## 🎓 Viva Questions & Answers

### Q1: What is Transfer Learning?
**A:** Using pre-trained models from large datasets (ImageNet) instead of training from scratch. Saves time and improves accuracy with smaller datasets.

### Q2: Why ResNet50 vs VGG16?
**A:** 
- ResNet50: Faster, better accuracy, skip connections
- VGG16: Simple, interpretable, uses plain stacking

### Q3: What are skip connections?
**A:** Skip connections in ResNet allow gradients to flow directly through layers, preventing vanishing gradient problem.

### Q4: What is the image input size?
**A:** 224×224 pixels (standard for ImageNet pre-trained models)

### Q5: How many parameters?
**A:** ResNet50: ~25M, VGG16: ~138M

### Q6: Data augmentation techniques used?
**A:** Rotation, width/height shift, zoom, horizontal flip, fill_mode nearest

---

## 🐛 Troubleshooting

### Issue: "Model not found" error
**Solution:** Make sure you trained the models first
```bash
python generate_dataset.py
python resnet_model.py
python vgg_model.py
```

### Issue: Port 5000 already in use
**Solution:** Edit app.py, change port:
```python
app.run(debug=True, host='127.0.0.1', port=5001)
```

### Issue: Out of memory error
**Solution:** Reduce BATCH_SIZE in training scripts:
```python
BATCH_SIZE = 16  # Changed from 32
```

### Issue: Slow training
**Solution:** Use GPU (if available) - TensorFlow will automatically use it

---

## 📚 Technologies Used

- **Deep Learning**: TensorFlow, Keras
- **Web Framework**: Flask
- **Frontend**: HTML5, CSS3, JavaScript
- **Image Processing**: OpenCV, Pillow
- **Data Processing**: NumPy, Scikit-learn
- **Visualization**: Matplotlib

---

## 🔗 Project Pipeline

```
1. Generate Dataset
   ↓
2. Train ResNet50 → resnet_model.h5
   ↓
3. Train VGG16 → vgg_model.h5
   ↓
4. Start Flask App
   ↓
5. Upload Image → Predictions from both models
   ↓
6. Display Results + Comparison
```

---

## 💡 Next Steps (Optional Improvements)

- [ ] Fine-tune models with unfrozen layers
- [ ] Use real garbage dataset (Google Open Images)
- [ ] Add MobileNet for efficiency comparison
- [ ] Deploy on Heroku/AWS
- [ ] Add confidence threshold filtering
- [ ] Create REST API endpoints
- [ ] Add batch prediction feature
- [ ] Train on GPU (CUDA setup)

---

## 📝 Notes

- **Synthetic Dataset**: Generated using PIL with colored shapes to represent different garbage types
- **Training Time**: ~2-5 minutes per model (on CPU)
- **Accuracy Range**: 70-95% depending on dataset quality
- **GPU Acceleration**: Training ~5-10x faster with NVIDIA GPU

---

## ✨ Credits

Built as a deep learning project demonstrating transfer learning concepts using state-of-the-art computer vision models.

---

## 📧 Contact & Support

For issues or questions, ensure:
1. All dependencies are installed correctly
2. Dataset is generated before training
3. Models are trained before running Flask app
4. Virtual environment is activated

---

**Happy Garbage Classification! ♻️🤖**
