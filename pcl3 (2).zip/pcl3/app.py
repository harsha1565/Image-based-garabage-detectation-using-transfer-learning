import os
import shutil
import numpy as np
from flask import Flask, render_template, request, jsonify, url_for
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.vgg16 import VGG16 as VGGTop, preprocess_input as vgg_preprocess, decode_predictions
from werkzeug.utils import secure_filename
import warnings
warnings.filterwarnings('ignore')

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Configuration
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
BIN_FOLDER = os.path.join(UPLOAD_FOLDER, 'bins')
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif', 'bmp'}
IMG_SIZE = 224

# Create upload and bin folders if they don't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(BIN_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Class labels (must match the directory order used by training)
classes = ['glass', 'metal', 'organic', 'paper', 'plastic']
bin_labels = {
    'plastic': 'Plastic Bin',
    'paper': 'Paper Bin',
    'metal': 'Metal Bin',
    'glass': 'Glass Bin',
    'organic': 'Organic Bin'
}

# Load models
print("🔄 Loading Models...")
vgg_model = None
vgg_top_model = None

try:
    vgg_model = load_model("vgg_model.h5")
    print("✓ Custom VGG16 Model Loaded")
except Exception as e:
    print(f"❌ Error loading custom VGG16 model: {e}")
    print("⚠️  Custom VGG16 model not loaded. You can still use ImageNet fallback.")

try:
    vgg_top_model = VGGTop(weights='imagenet')
    print("✓ ImageNet VGG16 Loaded")
except Exception as e:
    print(f"❌ Error loading ImageNet VGG16: {e}")
    print("⚠️  ImageNet fallback model not available.")


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def predict_garbage(img_path, model):
    """Predict garbage class using a custom trained model"""
    if model is None:
        return None, 0, None

    try:
        img = image.load_img(img_path, target_size=(IMG_SIZE, IMG_SIZE))
        img_array = image.img_to_array(img)
        img_array = np.expand_dims(img_array, axis=0)
        img_array = img_array / 255.0
        
        prediction = model.predict(img_array, verbose=0)[0]
        predicted_class = classes[np.argmax(prediction)]
        confidence = float(np.max(prediction)) * 100
        return predicted_class, confidence, prediction
    except Exception:
        return None, 0, None


def get_model_prediction(img_path, custom_model, imagenet_model, preprocess_func):
    """Predict using a custom model if available, otherwise use ImageNet fallback."""
    if custom_model is not None:
        return predict_garbage(img_path, custom_model)
    if imagenet_model is not None:
        prediction_class, confidence = predict_imagenet(img_path, imagenet_model, preprocess_func)
        return prediction_class, confidence, None
    return None, 0, None


def save_to_bin(final_class, source_path, filename):
    """Copy the uploaded image into the corresponding bin folder."""
    if final_class not in classes:
        return
    bin_dir = os.path.join(BIN_FOLDER, final_class)
    os.makedirs(bin_dir, exist_ok=True)

    dest_path = os.path.join(bin_dir, filename)
    if os.path.exists(dest_path):
        base, ext = os.path.splitext(filename)
        dest_path = os.path.join(bin_dir, f"{base}_{int(np.floor(np.random.rand() * 10000))}{ext}")
    try:
        shutil.copy2(source_path, dest_path)
    except Exception:
        pass


def imagenet_to_garbage_class(name: str):
    name = name.lower()
    glass_keywords = ['wine_bottle', 'beer_bottle', 'cocktail_shaker', 'vase', 'glass', 'jar', 'pitcher', 'mug', 'cup']
    plastic_keywords = ['water_bottle', 'plastic_bag', 'soda_bottle', 'milk_can', 'pill_bottle', 'plastic_bottle', 'bottle', 'container', 'tupperware', 'shampoo_bottle', 'detergent_bottle', 'soap_dispenser', 'suitcase']
    paper_keywords = ['newspaper', 'envelope', 'book', 'notebook', 'folder', 'file', 'paper', 'magazine', 'cardboard', 'pad', 'ledger']
    metal_keywords = ['can', 'tin', 'spoon', 'fork', 'hammer', 'wrench', 'screwdriver', 'chain', 'canned', 'nail', 'bolt', 'saucer', 'pan', 'pot', 'metal']
    organic_keywords = ['banana', 'apple', 'orange', 'lemon', 'mushroom', 'broccoli', 'pineapple', 'garlic', 'tomato', 'strawberry', 'pear', 'avocado', 'onion', 'potato', 'carrot', 'vegetable', 'fruit', 'salad']

    if any(keyword in name for keyword in glass_keywords):
        return 'glass'
    if any(keyword in name for keyword in plastic_keywords):
        return 'plastic'
    if any(keyword in name for keyword in paper_keywords):
        return 'paper'
    if any(keyword in name for keyword in metal_keywords):
        return 'metal'
    if any(keyword in name for keyword in organic_keywords):
        return 'organic'
    if 'bottle' in name and 'glass' not in name and 'wine' not in name and 'beer' not in name:
        return 'plastic'
    if 'jar' in name or 'vase' in name:
        return 'glass'
    if 'can' in name or 'tin' in name:
        return 'metal'
    if 'paper' in name or 'cardboard' in name or 'notebook' in name or 'envelope' in name:
        return 'paper'
    if 'vegetable' in name or 'fruit' in name or 'green' in name:
        return 'organic'
    return None


def predict_imagenet(img_path, model, preprocess_func):
    if model is None:
        return None, 0

    try:
        img = image.load_img(img_path, target_size=(IMG_SIZE, IMG_SIZE))
        x = image.img_to_array(img)
        x = np.expand_dims(x, axis=0)
        x = preprocess_func(x)

        predictions = model.predict(x, verbose=0)
        decoded = decode_predictions(predictions, top=5)[0]

        for _, name, prob in decoded:
            mapped_class = imagenet_to_garbage_class(name)
            if mapped_class:
                return mapped_class, float(prob * 100)

        top_name = decoded[0][1].lower()
        fallback = imagenet_to_garbage_class(top_name)
        return fallback if fallback else 'plastic', float(decoded[0][2] * 100)
    except Exception:
        return None, 0


def get_best_prediction(img_path):
    """Get prediction from VGG16 custom model or fallback to ImageNet VGG16."""
    vgg_class, vgg_conf, vgg_probs = get_model_prediction(img_path, vgg_model, vgg_top_model, vgg_preprocess)

    print(f"\n🔍 Model Predictions:")
    print(f"   VGG16:    {vgg_class} ({vgg_conf:.2f}%)")

    if vgg_class is not None:
        print(f"✅ Using VGG16 prediction {vgg_class}")
        return vgg_class, vgg_conf, vgg_class, vgg_conf

    print(f"⚠️  No custom VGG16 model available - using ImageNet fallback")
    if vgg_top_model is not None:
        imagenet_class, imagenet_conf = predict_imagenet(img_path, vgg_top_model, vgg_preprocess)
        print(f"   ImageNet fallback: {imagenet_class} ({imagenet_conf:.2f}%)")
        return imagenet_class, imagenet_conf, None, 0

    return None, 0, None, 0


@app.route('/')
def home():
    """Home page"""
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    """API endpoint for prediction"""
    try:
        # Check if file is present
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Check if file is allowed
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type. Allowed: jpg, jpeg, png, gif, bmp'}), 400
        
        # Save file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        image_url = url_for('static', filename=f'uploads/{filename}')
        
        # Make predictions using the best available pipeline
        final_class, final_conf, vgg_class, vgg_conf = get_best_prediction(filepath)
        save_to_bin(final_class, filepath, filename)
        
        return jsonify({
            'success': True,
            'image_path': image_url,
            'final_prediction': {
                'class': final_class.upper() if final_class else 'UNKNOWN',
                'confidence': f"{final_conf:.2f}%" if final_conf else "0%",
                'bin': bin_labels.get(final_class, 'Unknown Bin') if final_class else 'Unknown Bin'
            },
            'vgg': {
                'class': vgg_class.upper() if vgg_class else 'UNKNOWN',
                'confidence': f"{vgg_conf:.2f}%" if vgg_conf else "0%"
            },
            'source': 'VGG16'
        })
    
    except Exception as e:
        return jsonify({'error': f'Error processing image: {str(e)}'}), 500

@app.route('/bin_contents', methods=['GET'])
def bin_contents():
    bin_name = request.args.get('bin', '').lower()
    if bin_name not in classes:
        return jsonify({'error': 'Invalid bin name'}), 400

    bin_path = os.path.join(BIN_FOLDER, bin_name)
    files = []
    if os.path.isdir(bin_path):
        for fname in sorted(os.listdir(bin_path)):
            if allowed_file(fname):
                files.append(url_for('static', filename=f'uploads/bins/{bin_name}/{fname}'))

    return jsonify({
        'bin': bin_name,
        'count': len(files),
        'files': files
    })

@app.route('/compare', methods=['GET'])
def compare():
    """API endpoint for model comparison info"""
    return jsonify({
        'models': {
            'VGG16': {
                'depth': '16 layers',
                'features': 'Simple sequential structure',
                'speed': 'Moderate',
                'advantages': 'Accurate for this waste classification task'
            }
        }
    })

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'Running',
        'models_loaded': True,
        'classes': classes
    })

if __name__ == '__main__':
    print("\n" + "=" * 60)
    print("🌐 Starting Garbage Classification Web App")
    print("=" * 60)
    print("📍 Open browser: http://127.0.0.1:5000/")
    print("=" * 60 + "\n")
    app.run(debug=True, host='127.0.0.1', port=5000)
